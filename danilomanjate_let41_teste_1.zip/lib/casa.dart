import 'imovel.dart';
import 'porta.dart';
import 'excepcoes.dart';

class Casa extends Imovel {
  int numQuartos;

  Casa(String id, String endereco, List<Porta> portas, this.numQuartos)
      : super(id, endereco, portas, 'casa') {
    if (numQuartos < 1 || numQuartos > 5) {
      throw DadosInvalidosException('Numero de quartos deve ser entre 1 e 5.');
    }
  }

  @override
  String toString() {
    return 'Casa [ id: $id | T$numQuartos | Endereco: $endereco | Portas: ${portas.length} ]';
  }
}
