import 'imovel.dart';
import 'casa.dart';
import 'porta.dart';

abstract class Condominio extends Imovel {
  List<Casa> casas;

  Condominio(String id, String endereco, List<Porta> portas, String tipo, this.casas)
      : super(id, endereco, portas, tipo);
}
