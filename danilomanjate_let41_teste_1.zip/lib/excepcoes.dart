class ImovelJaExisteException implements Exception {
  final String mensagem;
  ImovelJaExisteException(this.mensagem);

  @override
  String toString() => 'ImovelJaExisteException: $mensagem';
}

class ImovelNaoEncontradoException implements Exception {
  final String mensagem;
  ImovelNaoEncontradoException(this.mensagem);

  @override
  String toString() => 'ImovelNaoEncontradoException: $mensagem';
}

class DadosInvalidosException implements Exception {
  final String mensagem;
  DadosInvalidosException(this.mensagem);

  @override
  String toString() => 'DadosInvalidosException: $mensagem';
}
