import 'dart:math';
import 'operacoes.dart';
import 'imovel.dart';
import 'excepcoes.dart';

class GestaoImoveis implements Operacoes {

  final List<Imovel> _imoveis = [];

  @override
  void adicionar(Imovel imovel) {
    for (var i in _imoveis) {
      if (i.id == imovel.id) {
        throw ImovelJaExisteException('Ja existe um imovel com o id ${imovel.id}.');
      }
    }
    _imoveis.add(imovel);
    print('Imovel ${imovel.id} adicionado com sucesso.');
  }

  @override
  void remover(String id) {
    int antes = _imoveis.length;
    _imoveis.removeWhere((i) => i.id == id);
    if (_imoveis.length == antes) {
      throw ImovelNaoEncontradoException('Imovel com id $id nao encontrado.');
    }
    print('Imovel $id removido.');
  }

  @override
  Imovel consultar(String id) {
    for (var i in _imoveis) {
      if (i.id == id) return i;
    }
    throw ImovelNaoEncontradoException('Imovel com id $id nao encontrado.');
  }

  @override
  void eliminar(String id) => remover(id);

  @override
  List<Imovel> listarPorTipo(String tipo) {
    return _imoveis.where((i) => i.tipo == tipo).toList();
  }

  @override
  int totalPortasAbertas(String id) {
    Imovel imovel = consultar(id);
    return imovel.portas.where((p) => p.estaAberta).length;
  }

  @override
  void ordenar() {
    _imoveis.sort((a, b) {
      int cmpTipo = a.tipo.compareTo(b.tipo);
      if (cmpTipo != 0) return cmpTipo;
      return a.endereco.compareTo(b.endereco);
    });
    print('Lista ordenada por tipo e localizacao.');
  }

  @override
  void embaralhar() {
    _imoveis.shuffle(Random());
    print('Lista embaralhada.');
  }

  void listarTodos() {
    if (_imoveis.isEmpty) {
      print('Nenhum imovel cadastrado.');
      return;
    }
    for (var i in _imoveis) {
      print('  $i');
    }
  }
}
