import 'porta.dart';
import 'excepcoes.dart';

abstract class Imovel {
  String id;
  String endereco;
  List<Porta> portas;
  String tipo;

  Imovel(this.id, this.endereco, this.portas, this.tipo) {
    if (id.trim().isEmpty) throw DadosInvalidosException('O ID do imovel nao pode estar vazio.');
    if (endereco.trim().isEmpty) throw DadosInvalidosException('O endereco nao pode estar vazio.');
  }

  @override
  String toString();
}
