import 'porta.dart';
import 'casa.dart';
import 'predio.dart';
import 'vila.dart';
import 'gestao_imoveis.dart';
import 'excepcoes.dart';

void mostrarMenu() {

  print('----------IMOBILIÁRIA PDM----------');
  print('\n');
  print(' 1. Listar todos os imoveis');
  print(' 2. Consultar imovel por ID');
  print(' 3. Listar por tipo');
  print(' 4. Total de portas abertas');
  print(' 5. Ordenar lista');
  print(' 6. Embaralhar lista');
  print(' 7. Remover imovel');
  print(' 0. Sair');
}

void main() {
  GestaoImoveis gestao = GestaoImoveis();
  print('\n--- A carregar imoveis iniciais ---');

  try {
    gestao.adicionar(Casa(
      'C001',
      'Av. Eduardo Mondlane, 77, Maputo',
      [Porta(2.0, 0.9), Porta(2.0, 0.8, estaAberta: true), Porta(2.1, 1.0)],
      3,
    ));

    gestao.adicionar(Predio(
      'P001',
      'Rua da Resistência, 77, Matola',
      [Porta(2.5, 1.2), Porta(2.5, 1.2, estaAberta: true)],
      [
        Casa('C002', 'Apartamento 101', [Porta(2.0, 0.9)], 2),
        Casa('C003', 'Apartamento 201', [Porta(2.0, 0.9), Porta(2.0, 0.8)], 3),
        Casa('C004', 'Apartamento 301', [Porta(2.0, 0.9)], 1),
      ],
      5,
    ));

    gestao.adicionar(Vila(
      'V001',
      'Condomínio Panorama, Boane',
      [Porta(3.0, 1.5), Porta(2.2, 1.0), Porta(2.2, 1.0, estaAberta: true)],
      [
        Casa('C005', 'Casa A', [Porta(2.0, 0.9), Porta(2.0, 0.8)], 4),
        Casa('C006', 'Casa B', [Porta(2.0, 0.9)], 3),
      ],
    ));

  } on DadosInvalidosException catch (e) {
    print('Erro de validação ao carregar: $e');
  } on ImovelJaExisteException catch (e) {
    print('Erro ao carregar: $e');
  }

  bool sair = false;

  while (!sair) {
    mostrarMenu();
    print('Escolha: ');

    List<String> simulacao = ['1', '2', '3', '4', '5', '6', '7_erro', '0'];

    for (String opcao in simulacao) {
      print('\n> Opção: $opcao');

      switch (opcao) {

        case '1':
          print('\n--- Todos os imoveis ---');
          gestao.listarTodos();
          break;

        case '2':
          print('\n--- Consultar C001 ---');
          try {
            var imovel = gestao.consultar('C001');
            print('  $imovel');
          } on ImovelNaoEncontradoException catch (e) {
            print('  $e');
          }
          break;

        case '3':
          print('\n--- Listar por tipo: casa ---');
          var casas = gestao.listarPorTipo('casa');
          for (var c in casas) { print('  $c'); }

          print('\n--- Listar por tipo: predio ---');
          var predios = gestao.listarPorTipo('predio');
          for (var p in predios) { print('  $p'); }
          break;

        case '4':
          print('\n--- Portas abertas em V001 ---');
          try {
            int n = gestao.totalPortasAbertas('V001');
            print(' Total de portas abertas: $n');
          } on ImovelNaoEncontradoException catch (e) {
            print('  $e');
          }
          break;

        case '5':
          print('\n--- Ordenar ---');
          gestao.ordenar();
          gestao.listarTodos();
          break;

        case '6':
          print('\n--- Embaralhar ---');
          gestao.embaralhar();
          gestao.listarTodos();
          break;

        case '7_erro':
          print('\n--- Testar excepcoes ---');

          try {
            gestao.adicionar(Casa('C001', 'Teste', [Porta(2.0, 0.9)], 2));
          } on ImovelJaExisteException catch (e) {
            print('Excepcao capturada: $e');
          }


          try {
            gestao.consultar('X999');
          } on ImovelNaoEncontradoException catch (e) {
            print('Excepcao capturada: $e');
          }


          try {
            Casa('', 'Teste', [Porta(2.0, 0.9)], 2);
          } on DadosInvalidosException catch (e) {
            print('Excepcao capturada: $e');
          }

          try {
            var p = gestao.consultar('P001') as Predio;
            p.adicionarAndar();
            print('  $p');
          } on ImovelNaoEncontradoException catch (e) {
            print('  $e');
          }
          break;

        case '0':
          print('\nA sair...');
          sair = true;
          break;
      }
    }

    break;
  }

  print('\nPrograma terminado');
}
