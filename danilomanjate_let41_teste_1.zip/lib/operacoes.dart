import 'imovel.dart';

abstract class Operacoes {
  void adicionar(Imovel imovel);
  void remover(String id);
  Imovel consultar(String id);
  void eliminar(String id);
  List<Imovel> listarPorTipo(String tipo);
  int totalPortasAbertas(String id);
  void ordenar();
  void embaralhar();
}
