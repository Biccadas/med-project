class Porta {
  double comprimento;
  double largura;
  bool estaAberta;

  Porta(this.comprimento, this.largura, {this.estaAberta = false});

  void abrir() {
    estaAberta = true;
    print('  Porta aberta.');
  }

  void fechar() {
    estaAberta = false;
    print('  Porta fechada.');
  }

  String verificarEstado() => estaAberta ? 'Aberta' : 'Fechada';

  @override
  String toString() => 'Porta(${comprimento}m x ${largura}m - ${verificarEstado()})';
}
