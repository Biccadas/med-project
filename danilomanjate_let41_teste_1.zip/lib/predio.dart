import 'condominio.dart';
import 'casa.dart';
import 'porta.dart';
import 'excepcoes.dart';

class Predio extends Condominio {
  int numAndares;

  Predio(String id, String endereco, List<Porta> portas, List<Casa> casas, this.numAndares)
      : super(id, endereco, portas, 'predio', casas) {
    if (numAndares < 1) {
      throw DadosInvalidosException('O predio deve ter pelo menos 1 andar.');
    }
  }

  void adicionarAndar() {
    numAndares++;
    print('  Andar adicionado. Total de andares: $numAndares');
  }

  @override
  String toString() {
    return 'Predio [ id: $id | Andares: $numAndares | Casas: ${casas.length} | Endereço: $endereco | Portas: ${portas.length} ]';
  }
}
