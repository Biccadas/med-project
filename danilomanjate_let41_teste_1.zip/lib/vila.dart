import 'condominio.dart';
import 'casa.dart';
import 'porta.dart';

class Vila extends Condominio {
  Vila(String id, String endereco, List<Porta> portas, List<Casa> casas)
      : super(id, endereco, portas, 'vila', casas);

  @override
  String toString() {
    return 'Vila  [ id: $id | Casas: ${casas.length} | Endereço: $endereco | Portas: ${portas.length} ]';
  }
}
